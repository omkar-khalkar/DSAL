class record:
    def __init__(self):
        self.name = None
        self.no = None

    def set_name(self, name):
        self.name = name

    def set_no(self, no):
        self.no = no

    def get_name(self):
        return self.name

    def get_no(self):
        return self.no
